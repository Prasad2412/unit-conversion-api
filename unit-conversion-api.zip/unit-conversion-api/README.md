# Unit Conversion API

An ASP.NET Core Web API (.NET 10) that converts numbers between units of measurement.
Supported categories: **length**, **mass**, **temperature** and (as a bonus) **volume**.

- Layered solution: pure domain library (`Core`), thin HTTP layer (`Api`), automated tests (`Tests`).
- Strict input validation with consistent RFC 9457 `application/problem+json` error responses.
- Designed so that hundreds of units and new categories can be added without touching existing code.

## Prerequisites

- [.NET SDK 10.0](https://dotnet.microsoft.com/download) (`dotnet --version` should print `10.x`)

## Run locally

```bash
git clone <repository-url>
cd <repository-folder>

dotnet restore
dotnet run --project src/UnitConversion.Api
```

The API listens on `http://localhost:5080` (see `src/UnitConversion.Api/Properties/launchSettings.json`).

Try it:

```bash
curl -X POST http://localhost:5080/api/v1/conversions \
  -H "Content-Type: application/json" \
  -d '{ "category": "temperature", "fromUnit": "C", "toUnit": "F", "value": 100 }'
```

```json
{ "category": "temperature", "fromUnit": "celsius", "toUnit": "fahrenheit", "inputValue": 100, "result": 212 }
```

More ready-made requests are in [`src/UnitConversion.Api/UnitConversion.Api.http`](src/UnitConversion.Api/UnitConversion.Api.http)
(works with VS, Rider and the VS Code REST Client extension). In the Development environment the OpenAPI
document is served at `http://localhost:5080/openapi/v1.json`.

### Run the tests

```bash
dotnet test
```

### Run with Docker (optional)

```bash
docker build -t unit-conversion-api .
docker run --rm -p 8080:8080 unit-conversion-api
```

## API

| Method | Route                                  | Description                                |
|--------|----------------------------------------|--------------------------------------------|
| POST   | `/api/v1/conversions`                  | Convert a value from one unit to another   |
| GET    | `/api/v1/categories`                   | List supported categories                  |
| GET    | `/api/v1/categories/{category}/units`  | List units (codes, symbols, aliases)       |
| GET    | `/health`                              | Health check                               |

### `POST /api/v1/conversions`

| Field      | Type    | Required | Notes                                                                 |
|------------|---------|----------|-----------------------------------------------------------------------|
| `category` | string  | yes      | `length`, `mass`, `temperature`, `volume` (case-insensitive)          |
| `fromUnit` | string  | yes      | Unit code, symbol or alias, e.g. `meter`, `m`, `metre` (case-insensitive) |
| `toUnit`   | string  | yes      | Same as above, must belong to the same category                       |
| `value`    | number  | yes      | The number to convert                                                 |
| `precision`| integer | no       | Decimal places of the result, 0-10, default 6                         |

### Validation and error handling

All errors use `application/problem+json`. Field names are camelCase and match the request body.

| Situation                                                       | Status |
|-----------------------------------------------------------------|--------|
| Missing/empty fields, wrong JSON types, malformed JSON          | 400    |
| Field longer than 50 characters, `precision` outside 0-10       | 400    |
| Unknown category, unknown unit, unit from a different category  | 400    |
| Physically impossible value (below absolute zero, negative mass/volume) | 400 |
| Value so large the result overflows                             | 400    |
| Unknown category on `GET /categories/{category}/units`          | 404    |
| Unexpected server error                                         | 500 (generic body, no internals leaked) |

Example - below absolute zero:

```json
{
  "type": "https://tools.ietf.org/html/rfc9110#section-15.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "errors": { "value": ["-300 C is below the physical minimum for temperature."] },
  "traceId": "00-..."
}
```

## Project structure

```
src/
  UnitConversion.Core/          Domain + conversion engine, no framework/package dependencies
    Domain/                     UnitDefinition, UnitCategory, ICategoryDefinition
    Categories/                 One class per category (Length, Mass, Temperature, Volume)
    Services/                   Catalog, conversion service, exceptions, models
  UnitConversion.Api/           ASP.NET Core Web API
    Controllers/                Thin controllers (HTTP concerns only)
    Contracts/                  Request/response DTOs with validation attributes
    Infrastructure/             DI registration, exception handler, validation response factory
tests/
  UnitConversion.Tests/         Unit tests (engine) + integration tests (full HTTP pipeline)
.github/workflows/ci.yml        Build + test on every push and pull request
```

## Adding a new category or unit

- **New unit** in an existing category: add one `UnitDefinition.Linear(...)` line to that category class.
- **New category**: create a class implementing `ICategoryDefinition` in `Core/Categories`
  (see `VolumeCategory` for a minimal example). It is discovered automatically at start-up - no
  registration code to edit - and appears in the endpoints immediately.
- Add test cases to `UnitConversionServiceTests`.

## Design decisions and trade-offs

- **Base-unit conversion.** Every unit only knows how to convert to/from its category's base unit
  (meter, kilogram, Celsius, liter). Converting A -> B is `B.FromBase(A.ToBase(x))`. Supporting N units therefore
  needs N rules instead of N x N, which matters when the catalog grows to hundreds of units.
- **Temperature is not just a factor.** Celsius/Fahrenheit/Kelvin/Rankine have offsets, so units can supply custom
  to/from-base functions instead of a plain factor. Multiplication is ordered before division so common values such as
  212 F -> 100 C stay exact.
- **`decimal` instead of `double`.** Avoids results like `212.00000000000003`. The trade-off is a smaller range
  (about 7.9 x 10^28), so overflow is detected and reported as a 400. Results are rounded (default 6 decimals,
  configurable) and trailing zeros are removed.
- **Category is required.** Symbols collide across domains (e.g. `t` tonne, `st` stone, `pt` pint). Requiring the
  category removes the ambiguity and keeps validation messages precise (units are listed per category).
- **Data-driven, hardcoded for now.** Units live in code (as the brief allows) behind `ICategoryDefinition`, and the
  API depends only on `IUnitCatalog`. Moving the data to JSON or a database later means adding a new catalog
  implementation, with no changes to controllers or the conversion service.
- **Validation in two layers.** DataAnnotations handle the shape of the request (required, length, range, types).
  The domain service handles meaning (known units, same category, physical limits). Both produce the same error format.
- **Expected failures are exceptions mapped in one place** (`ConversionExceptionHandler`) so controllers stay
  free of error-handling code and the status-code mapping is easy to audit.
- **Case-insensitive identifiers with aliases** (`metre`, `kilo`, `lbs`) make the API forgiving without being ambiguous;
  duplicate identifiers inside a category fail fast at start-up.
- **Quality gates.** `TreatWarningsAsErrors`, analyzers, `.editorconfig`, `global.json` (SDK pinning) and a CI
  workflow keep a multi-developer codebase consistent.
- **Out of scope for this version:** authentication, rate limiting, caching, localization of unit names, and
  non-US gallon/pint variants (the US customary ones are documented as such).

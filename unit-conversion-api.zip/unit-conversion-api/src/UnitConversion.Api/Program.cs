using UnitConversion.Api.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddUnitConversion();

builder.Services
    .AddControllers()
    .ConfigureApiBehaviorOptions(options =>
        options.InvalidModelStateResponseFactory = ValidationResponseFactory.Create);

builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<ConversionExceptionHandler>();
builder.Services.AddHealthChecks();
builder.Services.AddOpenApi();

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi(); // GET /openapi/v1.json
}

app.UseHttpsRedirection();
app.MapControllers();
app.MapHealthChecks("/health");

app.Run();

// Required so the integration tests can reference the entry point.
public partial class Program;

namespace UnitConversion.Api.Contracts;

public sealed record ConvertResponse(
    string Category,
    string FromUnit,
    string ToUnit,
    decimal InputValue,
    decimal Result);

public sealed record CategoryResponse(string Name, string Description, int UnitCount);

public sealed record UnitResponse(string Code, string Symbol, string DisplayName, IReadOnlyCollection<string> Aliases);

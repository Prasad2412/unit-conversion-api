using System.ComponentModel.DataAnnotations;

namespace UnitConversion.Api.Contracts;

/// <summary>Request body for a unit conversion.</summary>
public sealed class ConvertRequest
{
    /// <summary>Conversion category, e.g. "length", "temperature", "mass".</summary>
    /// <example>length</example>
    [Required]
    [StringLength(50)]
    public string? Category { get; init; }

    /// <summary>Unit to convert from: unit code, symbol or alias (case-insensitive).</summary>
    /// <example>meter</example>
    [Required]
    [StringLength(50)]
    public string? FromUnit { get; init; }

    /// <summary>Unit to convert to: unit code, symbol or alias (case-insensitive).</summary>
    /// <example>foot</example>
    [Required]
    [StringLength(50)]
    public string? ToUnit { get; init; }

    /// <summary>The number to convert.</summary>
    /// <example>100</example>
    [Required]
    public decimal? Value { get; init; }

    /// <summary>Decimal places to round the result to (0-10). Defaults to 6.</summary>
    /// <example>4</example>
    [Range(0, 10)]
    public int? Precision { get; init; }
}

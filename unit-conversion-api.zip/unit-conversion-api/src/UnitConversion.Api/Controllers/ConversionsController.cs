using Microsoft.AspNetCore.Mvc;
using UnitConversion.Api.Contracts;
using UnitConversion.Core.Services;

namespace UnitConversion.Api.Controllers;

[ApiController]
[Route("api/v1/conversions")]
[Produces("application/json")]
public sealed class ConversionsController(IUnitConversionService conversionService) : ControllerBase
{
    /// <summary>Converts a number from one unit to another within the same category.</summary>
    /// <response code="200">The converted value.</response>
    /// <response code="400">Invalid input (missing fields, unknown category/unit, value out of range).</response>
    [HttpPost]
    [ProducesResponseType<ConvertResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    public ActionResult<ConvertResponse> Convert([FromBody] ConvertRequest request)
    {
        // [ApiController] has already rejected null/invalid models, so the nullable
        // properties are guaranteed to be populated here.
        var output = conversionService.Convert(new ConversionInput(
            request.Category!,
            request.FromUnit!,
            request.ToUnit!,
            request.Value!.Value,
            request.Precision ?? ConversionInput.DefaultPrecision));

        return Ok(new ConvertResponse(
            output.Category, output.FromUnit, output.ToUnit, output.InputValue, output.Result));
    }
}

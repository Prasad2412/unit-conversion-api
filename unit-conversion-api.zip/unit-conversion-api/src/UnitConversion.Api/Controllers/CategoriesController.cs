using Microsoft.AspNetCore.Mvc;
using UnitConversion.Api.Contracts;
using UnitConversion.Core.Services;

namespace UnitConversion.Api.Controllers;

[ApiController]
[Route("api/v1/categories")]
[Produces("application/json")]
public sealed class CategoriesController(IUnitCatalog catalog) : ControllerBase
{
    /// <summary>Lists all supported conversion categories.</summary>
    [HttpGet]
    [ProducesResponseType<IEnumerable<CategoryResponse>>(StatusCodes.Status200OK)]
    public ActionResult<IEnumerable<CategoryResponse>> GetCategories() =>
        Ok(catalog.Categories
            .OrderBy(c => c.Name)
            .Select(c => new CategoryResponse(c.Name, c.Description, c.Units.Count)));

    /// <summary>Lists the units supported by a category.</summary>
    /// <param name="category">Category name, e.g. "length".</param>
    /// <response code="404">The category does not exist.</response>
    [HttpGet("{category}/units")]
    [ProducesResponseType<IEnumerable<UnitResponse>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public ActionResult<IEnumerable<UnitResponse>> GetUnits(string category) =>
        Ok(catalog.GetCategory(category).Units
            .Select(u => new UnitResponse(u.Code, u.Symbol, u.DisplayName, u.Aliases)));
}

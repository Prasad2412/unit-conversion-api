using UnitConversion.Core.Domain;
using UnitConversion.Core.Services;

namespace UnitConversion.Api.Infrastructure;

public static class ServiceCollectionExtensions
{
    /// <summary>
    /// Registers the conversion engine and auto-discovers every <see cref="ICategoryDefinition"/>
    /// in the Core assembly, so adding a new category never requires touching this file.
    /// </summary>
    public static IServiceCollection AddUnitConversion(this IServiceCollection services)
    {
        var definitions = typeof(ICategoryDefinition).Assembly
            .GetTypes()
            .Where(t => t is { IsAbstract: false, IsInterface: false } && t.IsAssignableTo(typeof(ICategoryDefinition)));

        foreach (var type in definitions)
        {
            services.AddSingleton(typeof(ICategoryDefinition), type);
        }

        services.AddSingleton<IUnitCatalog, UnitCatalog>();
        services.AddSingleton<IUnitConversionService, UnitConversionService>();

        return services;
    }
}

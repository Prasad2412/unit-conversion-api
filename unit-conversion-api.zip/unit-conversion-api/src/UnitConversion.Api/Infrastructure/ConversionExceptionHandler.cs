using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using UnitConversion.Core.Services;

namespace UnitConversion.Api.Infrastructure;

/// <summary>
/// Translates expected domain exceptions into RFC 9457 problem responses.
/// Anything else is left to the default handler, which returns a generic 500
/// without leaking internals.
/// </summary>
public sealed partial class ConversionExceptionHandler(
    IProblemDetailsService problemDetailsService,
    ILogger<ConversionExceptionHandler> logger) : IExceptionHandler
{
    public async ValueTask<bool> TryHandleAsync(
        HttpContext httpContext, Exception exception, CancellationToken cancellationToken)
    {
        ProblemDetails? problem = exception switch
        {
            ConversionValidationException validation => new ValidationProblemDetails(validation.Errors)
            {
                Status = StatusCodes.Status400BadRequest,
                Title = "One or more validation errors occurred.",
            },
            CategoryNotFoundException notFound => new ProblemDetails
            {
                Status = StatusCodes.Status404NotFound,
                Title = "Category not found.",
                Detail = notFound.Message,
            },
            _ => null,
        };

        if (problem is null)
        {
            return false;
        }

        LogRejected(logger, exception.Message);

        httpContext.Response.StatusCode = problem.Status!.Value;

        return await problemDetailsService.TryWriteAsync(new ProblemDetailsContext
        {
            HttpContext = httpContext,
            ProblemDetails = problem,
        });
    }

    [LoggerMessage(Level = LogLevel.Information, Message = "Request rejected: {Reason}")]
    private static partial void LogRejected(ILogger logger, string reason);
}

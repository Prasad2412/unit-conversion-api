using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace UnitConversion.Api.Infrastructure;

/// <summary>
/// Makes automatic model-validation errors (400) use the same camelCase field names
/// as the rest of the API, e.g. "fromUnit" instead of "FromUnit" or "$.value".
/// </summary>
public static class ValidationResponseFactory
{
    public static IActionResult Create(ActionContext context)
    {
        var factory = context.HttpContext.RequestServices.GetRequiredService<ProblemDetailsFactory>();
        var details = factory.CreateValidationProblemDetails(context.HttpContext, context.ModelState);

        var normalized = details.Errors
            .GroupBy(e => Normalize(e.Key))
            .ToDictionary(g => g.Key, g => g.SelectMany(e => e.Value).ToArray());

        // A malformed body also yields a redundant "body is required" message; drop it when
        // a more specific error exists.
        if (normalized.TryGetValue("request", out var requestErrors) && normalized.Count + requestErrors.Length > 2)
        {
            var specific = requestErrors.Where(m => !m.EndsWith("field is required.", StringComparison.Ordinal)).ToArray();
            if (specific.Length > 0)
            {
                normalized["request"] = specific;
            }
            else if (normalized.Count > 1)
            {
                normalized.Remove("request");
            }
        }

        details.Errors.Clear();
        foreach (var (key, messages) in normalized)
        {
            details.Errors[key] = messages;
        }

        return new BadRequestObjectResult(details)
        {
            ContentTypes = { "application/problem+json" },
        };
    }

    private static string Normalize(string key)
    {
        var name = key.StartsWith("$.", StringComparison.Ordinal) ? key[2..] : key;

        // Whole-body problems (e.g. malformed JSON) have an empty key or "$".
        if (name is "" or "$")
        {
            return "request";
        }

        return char.ToLowerInvariant(name[0]) + name[1..];
    }
}

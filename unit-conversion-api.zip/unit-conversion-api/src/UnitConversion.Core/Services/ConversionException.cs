namespace UnitConversion.Core.Services;

/// <summary>Base type for all expected, caller-correctable conversion problems.</summary>
public abstract class ConversionException(string message) : Exception(message);

/// <summary>The request was understood but its content is invalid (maps to HTTP 400).</summary>
public sealed class ConversionValidationException : ConversionException
{
    public ConversionValidationException(string field, string message)
        : base(message) => Errors = new Dictionary<string, string[]> { [field] = [message] };

    public ConversionValidationException(IDictionary<string, string[]> errors)
        : base("One or more validation errors occurred.") => Errors = errors;

    /// <summary>Field name -> error messages.</summary>
    public IDictionary<string, string[]> Errors { get; }
}

/// <summary>A requested resource (e.g. a category) does not exist (maps to HTTP 404).</summary>
public sealed class CategoryNotFoundException(string category, IEnumerable<string> available)
    : ConversionException($"Category '{category}' was not found. Available categories: {string.Join(", ", available)}.");

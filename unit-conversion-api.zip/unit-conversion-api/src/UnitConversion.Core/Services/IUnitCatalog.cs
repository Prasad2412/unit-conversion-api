using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Services;

/// <summary>Read-only access to all registered unit categories.</summary>
public interface IUnitCatalog
{
    IReadOnlyCollection<UnitCategory> Categories { get; }

    /// <exception cref="CategoryNotFoundException">When the category does not exist.</exception>
    UnitCategory GetCategory(string name);

    bool TryGetCategory(string name, out UnitCategory category);
}

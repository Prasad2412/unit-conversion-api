using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Services;

public sealed class UnitConversionService(IUnitCatalog catalog) : IUnitConversionService
{
    public ConversionOutput Convert(ConversionInput input)
    {
        ArgumentNullException.ThrowIfNull(input);

        var errors = new Dictionary<string, string[]>();

        if (input.Precision is < 0 or > ConversionInput.MaxPrecision)
        {
            errors["precision"] = [$"Precision must be between 0 and {ConversionInput.MaxPrecision}."];
        }

        if (!catalog.TryGetCategory(input.Category.Trim(), out var category))
        {
            errors["category"] =
            [
                $"Unknown category '{input.Category}'. Available categories: " +
                $"{string.Join(", ", catalog.Categories.Select(c => c.Name).Order())}."
            ];

            // Without a category the units cannot be validated, so stop here.
            throw new ConversionValidationException(errors);
        }

        var from = ResolveUnit(category, input.FromUnit, "fromUnit", errors);
        var to = ResolveUnit(category, input.ToUnit, "toUnit", errors);

        if (errors.Count > 0 || from is null || to is null)
        {
            throw new ConversionValidationException(errors);
        }

        try
        {
            var baseValue = from.ToBase(input.Value);

            if (category.MinimumBaseValue is { } minimum && baseValue < minimum)
            {
                throw new ConversionValidationException(
                    "value",
                    $"{input.Value} {from.Symbol} is below the physical minimum for {category.Name}.");
            }

            var result = to.FromBase(baseValue);
            var rounded = Math.Round(result, input.Precision, MidpointRounding.AwayFromZero);

            // Dividing by 1.000... drops trailing zeros (328.083990 -> 328.08399) without changing the value.
            rounded /= 1.0000000000000000000000000000m;

            return new ConversionOutput(category.Name, from.Code, to.Code, input.Value, rounded);
        }
        catch (OverflowException)
        {
            throw new ConversionValidationException("value", "The value is too large to be converted.");
        }
    }

    private static UnitDefinition? ResolveUnit(
        UnitCategory category, string identifier, string field, Dictionary<string, string[]> errors)
    {
        if (category.TryGetUnit(identifier.Trim(), out var unit))
        {
            return unit;
        }

        errors[field] =
        [
            $"Unknown unit '{identifier}' for category '{category.Name}'. " +
            $"Supported units: {string.Join(", ", category.Units.Select(u => u.Code))}."
        ];

        return null;
    }
}

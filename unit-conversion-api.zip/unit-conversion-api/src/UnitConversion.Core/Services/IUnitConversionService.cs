namespace UnitConversion.Core.Services;

public interface IUnitConversionService
{
    /// <exception cref="ConversionValidationException">Invalid category/unit/value combination.</exception>
    ConversionOutput Convert(ConversionInput input);
}

using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Services;

public sealed class UnitCatalog : IUnitCatalog
{
    private readonly Dictionary<string, UnitCategory> _categories = new(StringComparer.OrdinalIgnoreCase);

    public UnitCatalog(IEnumerable<ICategoryDefinition> definitions)
    {
        foreach (var definition in definitions)
        {
            var category = definition.Create();
            if (!_categories.TryAdd(category.Name, category))
            {
                throw new InvalidOperationException($"Duplicate category '{category.Name}'.");
            }
        }
    }

    public IReadOnlyCollection<UnitCategory> Categories => _categories.Values;

    public bool TryGetCategory(string name, out UnitCategory category) =>
        _categories.TryGetValue(name, out category!);

    public UnitCategory GetCategory(string name) =>
        TryGetCategory(name, out var category)
            ? category
            : throw new CategoryNotFoundException(name, _categories.Keys.Order());
}

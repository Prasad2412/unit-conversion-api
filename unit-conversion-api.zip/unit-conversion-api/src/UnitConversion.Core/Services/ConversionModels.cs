namespace UnitConversion.Core.Services;

/// <summary>Input to the conversion service.</summary>
public sealed record ConversionInput(
    string Category,
    string FromUnit,
    string ToUnit,
    decimal Value,
    int Precision = ConversionInput.DefaultPrecision)
{
    public const int DefaultPrecision = 6;
    public const int MaxPrecision = 10;
}

/// <summary>Result of a successful conversion.</summary>
public sealed record ConversionOutput(
    string Category,
    string FromUnit,
    string ToUnit,
    decimal InputValue,
    decimal Result);

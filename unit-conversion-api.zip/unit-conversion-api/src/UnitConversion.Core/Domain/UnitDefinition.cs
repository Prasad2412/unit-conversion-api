namespace UnitConversion.Core.Domain;

/// <summary>
/// A single unit of measurement within a <see cref="UnitCategory"/>.
/// Every unit knows how to convert a value to and from the category's base unit,
/// which keeps the number of conversion rules linear (N units) instead of quadratic (N x N).
/// </summary>
public sealed class UnitDefinition
{
    private readonly Func<decimal, decimal> _toBase;
    private readonly Func<decimal, decimal> _fromBase;

    private UnitDefinition(
        string code,
        string symbol,
        string displayName,
        IReadOnlyCollection<string> aliases,
        Func<decimal, decimal> toBase,
        Func<decimal, decimal> fromBase)
    {
        Code = code;
        Symbol = symbol;
        DisplayName = displayName;
        Aliases = aliases;
        _toBase = toBase;
        _fromBase = fromBase;
    }

    /// <summary>Stable machine-friendly identifier, e.g. "meter".</summary>
    public string Code { get; }

    /// <summary>Short symbol, e.g. "m".</summary>
    public string Symbol { get; }

    /// <summary>Human readable name, e.g. "Meter".</summary>
    public string DisplayName { get; }

    /// <summary>Additional accepted spellings, e.g. "metre".</summary>
    public IReadOnlyCollection<string> Aliases { get; }

    public decimal ToBase(decimal value) => _toBase(value);

    public decimal FromBase(decimal value) => _fromBase(value);

    /// <summary>Creates a unit that is a simple multiple of the base unit (base = value * factor).</summary>
    public static UnitDefinition Linear(
        string code,
        string symbol,
        string displayName,
        decimal factorToBase,
        params string[] aliases)
    {
        if (factorToBase <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(factorToBase), "Factor must be positive.");
        }

        return new UnitDefinition(
            code, symbol, displayName, aliases,
            toBase: v => v * factorToBase,
            fromBase: v => v / factorToBase);
    }

    /// <summary>Creates a unit with arbitrary conversion functions (e.g. temperature scales with offsets).</summary>
    public static UnitDefinition Custom(
        string code,
        string symbol,
        string displayName,
        Func<decimal, decimal> toBase,
        Func<decimal, decimal> fromBase,
        params string[] aliases) =>
        new(code, symbol, displayName, aliases, toBase, fromBase);
}

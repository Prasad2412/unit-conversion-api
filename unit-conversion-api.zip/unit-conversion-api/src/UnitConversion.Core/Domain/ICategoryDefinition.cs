namespace UnitConversion.Core.Domain;

/// <summary>
/// Implement this interface to add a new conversion category. Implementations are
/// discovered automatically at start-up, so no other code needs to change.
/// </summary>
public interface ICategoryDefinition
{
    UnitCategory Create();
}

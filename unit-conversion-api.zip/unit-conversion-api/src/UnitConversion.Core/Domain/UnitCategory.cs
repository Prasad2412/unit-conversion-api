namespace UnitConversion.Core.Domain;

/// <summary>
/// A group of units that can be converted between each other (length, mass, temperature, ...).
/// </summary>
public sealed class UnitCategory
{
    private readonly Dictionary<string, UnitDefinition> _lookup = new(StringComparer.OrdinalIgnoreCase);

    public UnitCategory(
        string name,
        string description,
        IEnumerable<UnitDefinition> units,
        decimal? minimumBaseValue = null)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);

        Name = name;
        Description = description;
        MinimumBaseValue = minimumBaseValue;
        Units = units.ToList().AsReadOnly();

        foreach (var unit in Units)
        {
            foreach (var key in unit.Aliases.Append(unit.Code).Append(unit.Symbol))
            {
                if (!_lookup.TryAdd(key, unit) && !ReferenceEquals(_lookup[key], unit))
                {
                    throw new InvalidOperationException(
                        $"Duplicate unit identifier '{key}' in category '{name}'.");
                }
            }
        }
    }

    public string Name { get; }

    public string Description { get; }

    public IReadOnlyList<UnitDefinition> Units { get; }

    /// <summary>
    /// Smallest physically meaningful value expressed in the base unit
    /// (e.g. absolute zero for temperature, zero for mass). Null means "no lower bound".
    /// </summary>
    public decimal? MinimumBaseValue { get; }

    public bool TryGetUnit(string identifier, out UnitDefinition unit) =>
        _lookup.TryGetValue(identifier, out unit!);
}

using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Categories;

/// <summary>
/// Temperature. Base unit: degree Celsius. Scales have offsets, so they use custom
/// conversion functions. Values below absolute zero (-273.15 °C) are rejected.
/// </summary>
public sealed class TemperatureCategory : ICategoryDefinition
{
    public const string Name = "temperature";

    private const decimal AbsoluteZeroCelsius = -273.15m;

    public UnitCategory Create() => new(
        Name,
        "Temperature scales. Base unit: degree Celsius.",
        [
            UnitDefinition.Custom(
                "celsius", "C", "Degree Celsius",
                toBase: v => v,
                fromBase: v => v,
                "degc", "centigrade"),
            // Multiply before dividing so common values (e.g. 212 °F) stay exact.
            UnitDefinition.Custom(
                "fahrenheit", "F", "Degree Fahrenheit",
                toBase: v => (v - 32m) * 5m / 9m,
                fromBase: v => (v * 9m / 5m) + 32m,
                "degf"),
            UnitDefinition.Custom(
                "kelvin", "K", "Kelvin",
                toBase: v => v + AbsoluteZeroCelsius,
                fromBase: v => v - AbsoluteZeroCelsius),
            UnitDefinition.Custom(
                "rankine", "R", "Degree Rankine",
                toBase: v => (v - 491.67m) * 5m / 9m,
                fromBase: v => (v * 9m / 5m) + 491.67m,
                "degr"),
        ],
        minimumBaseValue: AbsoluteZeroCelsius);
}

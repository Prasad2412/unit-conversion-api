using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Categories;

/// <summary>Volume (bonus category). Base unit: liter. Gallons/cups are US customary.</summary>
public sealed class VolumeCategory : ICategoryDefinition
{
    public const string Name = "volume";

    public UnitCategory Create() => new(
        Name,
        "Liquid volume. Base unit: liter. Gallon, quart, pint and cup are US customary units.",
        [
            UnitDefinition.Linear("milliliter", "ml", "Milliliter", 0.001m, "millilitre"),
            UnitDefinition.Linear("liter", "l", "Liter", 1m, "litre", "liters", "litres"),
            UnitDefinition.Linear("cubic-meter", "m3", "Cubic meter", 1000m),
            UnitDefinition.Linear("teaspoon", "tsp", "Teaspoon (US)", 0.00492892159375m),
            UnitDefinition.Linear("tablespoon", "tbsp", "Tablespoon (US)", 0.01478676478125m),
            UnitDefinition.Linear("cup", "cup", "Cup (US)", 0.2365882365m, "cups"),
            UnitDefinition.Linear("pint", "pt", "Pint (US)", 0.473176473m, "pints"),
            UnitDefinition.Linear("quart", "qt", "Quart (US)", 0.946352946m, "quarts"),
            UnitDefinition.Linear("gallon", "gal", "Gallon (US)", 3.785411784m, "gallons"),
        ],
        minimumBaseValue: 0m);
}

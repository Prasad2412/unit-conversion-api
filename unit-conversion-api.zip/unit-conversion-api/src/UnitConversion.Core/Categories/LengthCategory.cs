using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Categories;

/// <summary>Length. Base unit: meter.</summary>
public sealed class LengthCategory : ICategoryDefinition
{
    public const string Name = "length";

    public UnitCategory Create() => new(
        Name,
        "Distance and length. Base unit: meter.",
        [
            UnitDefinition.Linear("millimeter", "mm", "Millimeter", 0.001m, "millimetre"),
            UnitDefinition.Linear("centimeter", "cm", "Centimeter", 0.01m, "centimetre"),
            UnitDefinition.Linear("meter", "m", "Meter", 1m, "metre"),
            UnitDefinition.Linear("kilometer", "km", "Kilometer", 1000m, "kilometre"),
            UnitDefinition.Linear("inch", "in", "Inch", 0.0254m, "inches"),
            UnitDefinition.Linear("foot", "ft", "Foot", 0.3048m, "feet"),
            UnitDefinition.Linear("yard", "yd", "Yard", 0.9144m, "yards"),
            UnitDefinition.Linear("mile", "mi", "Mile", 1609.344m, "miles"),
            UnitDefinition.Linear("nautical-mile", "nmi", "Nautical mile", 1852m, "nautical-miles"),
        ]);
}

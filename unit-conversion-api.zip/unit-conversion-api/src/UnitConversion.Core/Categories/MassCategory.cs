using UnitConversion.Core.Domain;

namespace UnitConversion.Core.Categories;

/// <summary>Weight / mass. Base unit: kilogram. Negative mass is rejected.</summary>
public sealed class MassCategory : ICategoryDefinition
{
    public const string Name = "mass";

    public UnitCategory Create() => new(
        Name,
        "Weight and mass. Base unit: kilogram.",
        [
            UnitDefinition.Linear("milligram", "mg", "Milligram", 0.000001m, "milligrams"),
            UnitDefinition.Linear("gram", "g", "Gram", 0.001m, "grams"),
            UnitDefinition.Linear("kilogram", "kg", "Kilogram", 1m, "kilograms", "kilo"),
            UnitDefinition.Linear("tonne", "t", "Metric tonne", 1000m, "tonnes", "metric-ton"),
            UnitDefinition.Linear("ounce", "oz", "Ounce", 0.028349523125m, "ounces"),
            UnitDefinition.Linear("pound", "lb", "Pound", 0.45359237m, "pounds", "lbs"),
            UnitDefinition.Linear("stone", "st", "Stone", 6.35029318m, "stones"),
        ],
        minimumBaseValue: 0m);
}

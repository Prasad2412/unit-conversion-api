using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc.Testing;

namespace UnitConversion.Tests;

public class ApiIntegrationTests(WebApplicationFactory<Program> factory) : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client = factory.CreateClient();

    private const string Url = "/api/v1/conversions";

    [Fact]
    public async Task Post_ValidRequest_Returns200WithResult()
    {
        var response = await _client.PostAsJsonAsync(Url, new
        {
            category = "temperature",
            fromUnit = "C",
            toUnit = "F",
            value = 100,
        });

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal(212m, json.RootElement.GetProperty("result").GetDecimal());
        Assert.Equal("celsius", json.RootElement.GetProperty("fromUnit").GetString());
    }

    [Fact]
    public async Task Post_MissingFields_Returns400WithFieldErrors()
    {
        var response = await _client.PostAsJsonAsync(Url, new { category = "length" });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("application/problem+json", response.Content.Headers.ContentType?.MediaType);

        var errors = await ReadErrorsAsync(response);
        Assert.True(errors.TryGetProperty("fromUnit", out _));
        Assert.True(errors.TryGetProperty("toUnit", out _));
        Assert.True(errors.TryGetProperty("value", out _));
    }

    [Fact]
    public async Task Post_UnknownUnit_Returns400()
    {
        var response = await _client.PostAsJsonAsync(Url, new
        {
            category = "length",
            fromUnit = "parsec",
            toUnit = "meter",
            value = 1,
        });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.True((await ReadErrorsAsync(response)).TryGetProperty("fromUnit", out _));
    }

    [Fact]
    public async Task Post_BelowAbsoluteZero_Returns400()
    {
        var response = await _client.PostAsJsonAsync(Url, new
        {
            category = "temperature",
            fromUnit = "C",
            toUnit = "K",
            value = -300,
        });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.True((await ReadErrorsAsync(response)).TryGetProperty("value", out _));
    }

    [Fact]
    public async Task Post_PrecisionOutOfRange_Returns400()
    {
        var response = await _client.PostAsJsonAsync(Url, new
        {
            category = "length",
            fromUnit = "m",
            toUnit = "ft",
            value = 1,
            precision = 99,
        });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.True((await ReadErrorsAsync(response)).TryGetProperty("precision", out _));
    }

    [Fact]
    public async Task Post_MalformedJson_Returns400()
    {
        using var content = new StringContent("{ not json", System.Text.Encoding.UTF8, "application/json");

        var response = await _client.PostAsync(Url, content);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Post_NonNumericValue_Returns400()
    {
        using var content = new StringContent(
            "{\"category\":\"mass\",\"fromUnit\":\"kg\",\"toUnit\":\"g\",\"value\":\"abc\"}",
            System.Text.Encoding.UTF8,
            "application/json");

        var response = await _client.PostAsync(Url, content);

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task GetCategories_ReturnsAtLeastRequiredCategories()
    {
        var response = await _client.GetAsync("/api/v1/categories");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);

        var body = await response.Content.ReadAsStringAsync();
        Assert.Contains("length", body, StringComparison.Ordinal);
        Assert.Contains("temperature", body, StringComparison.Ordinal);
        Assert.Contains("mass", body, StringComparison.Ordinal);
    }

    [Fact]
    public async Task GetUnits_UnknownCategory_Returns404()
    {
        var response = await _client.GetAsync("/api/v1/categories/nope/units");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Health_ReturnsHealthy()
    {
        var response = await _client.GetAsync("/health");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    private static async Task<JsonElement> ReadErrorsAsync(HttpResponseMessage response)
    {
        var json = await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync());
        return json.RootElement.GetProperty("errors").Clone();
    }
}

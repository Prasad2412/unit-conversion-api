using UnitConversion.Core.Categories;
using UnitConversion.Core.Domain;
using UnitConversion.Core.Services;

namespace UnitConversion.Tests;

public class UnitConversionServiceTests
{
    private readonly UnitConversionService _service = new(new UnitCatalog(
    [
        new LengthCategory(),
        new MassCategory(),
        new TemperatureCategory(),
        new VolumeCategory(),
    ]));

    [Theory]
    [InlineData("length", "meter", "foot", 100, 328.08399)]
    [InlineData("length", "mile", "kilometer", 1, 1.609344)]
    [InlineData("length", "in", "cm", 1, 2.54)]
    [InlineData("mass", "kg", "lb", 1, 2.204623)]
    [InlineData("mass", "pound", "gram", 1, 453.59237)]
    [InlineData("temperature", "C", "F", 100, 212)]
    [InlineData("temperature", "F", "C", 32, 0)]
    [InlineData("temperature", "K", "C", 0, -273.15)]
    [InlineData("temperature", "F", "K", 212, 373.15)]
    [InlineData("volume", "gal", "l", 1, 3.785412)]
    public void Convert_ReturnsExpectedResult(
        string category, string from, string to, double value, double expected)
    {
        var output = _service.Convert(new ConversionInput(category, from, to, (decimal)value));

        Assert.Equal((decimal)expected, output.Result);
    }

    [Fact]
    public void Convert_SameUnit_ReturnsSameValue()
    {
        var output = _service.Convert(new ConversionInput("length", "m", "metre", 42.5m));

        Assert.Equal(42.5m, output.Result);
    }

    [Fact]
    public void Convert_IsCaseInsensitive_AndAcceptsAliases()
    {
        var output = _service.Convert(new ConversionInput("LENGTH", "Metre", "FEET", 1m));

        Assert.Equal("length", output.Category);
        Assert.Equal("meter", output.FromUnit);
        Assert.Equal("foot", output.ToUnit);
    }

    [Fact]
    public void Convert_RoundsToRequestedPrecision()
    {
        var output = _service.Convert(new ConversionInput("length", "m", "ft", 1m, Precision: 2));

        Assert.Equal(3.28m, output.Result);
    }

    [Fact]
    public void Convert_UnknownCategory_Throws()
    {
        var ex = Assert.Throws<ConversionValidationException>(
            () => _service.Convert(new ConversionInput("speed", "a", "b", 1m)));

        Assert.Contains("category", ex.Errors.Keys);
    }

    [Fact]
    public void Convert_UnitFromAnotherCategory_ReportsBothUnits()
    {
        var ex = Assert.Throws<ConversionValidationException>(
            () => _service.Convert(new ConversionInput("length", "kg", "parsec", 1m)));

        Assert.Contains("fromUnit", ex.Errors.Keys);
        Assert.Contains("toUnit", ex.Errors.Keys);
    }

    [Theory]
    [InlineData("temperature", "C", "K", -273.16)]
    [InlineData("temperature", "K", "C", -1)]
    [InlineData("mass", "kg", "g", -1)]
    public void Convert_BelowPhysicalMinimum_Throws(string category, string from, string to, double value)
    {
        var ex = Assert.Throws<ConversionValidationException>(
            () => _service.Convert(new ConversionInput(category, from, to, (decimal)value)));

        Assert.Contains("value", ex.Errors.Keys);
    }

    [Fact]
    public void Convert_AbsoluteZero_IsAllowed()
    {
        var output = _service.Convert(new ConversionInput("temperature", "C", "K", -273.15m));

        Assert.Equal(0m, output.Result);
    }

    [Theory]
    [InlineData(-1)]
    [InlineData(11)]
    public void Convert_InvalidPrecision_Throws(int precision)
    {
        var ex = Assert.Throws<ConversionValidationException>(
            () => _service.Convert(new ConversionInput("length", "m", "ft", 1m, precision)));

        Assert.Contains("precision", ex.Errors.Keys);
    }

    [Fact]
    public void Convert_Overflow_IsReportedAsValidationError()
    {
        var ex = Assert.Throws<ConversionValidationException>(
            () => _service.Convert(new ConversionInput("mass", "kg", "mg", decimal.MaxValue)));

        Assert.Contains("value", ex.Errors.Keys);
    }
}

public class UnitCatalogTests
{
    [Fact]
    public void AllBuiltInCategories_CanBeConstructed_WithoutDuplicateIdentifiers()
    {
        var catalog = new UnitCatalog(
        [
            new LengthCategory(), new MassCategory(), new TemperatureCategory(), new VolumeCategory(),
        ]);

        Assert.Equal(4, catalog.Categories.Count);
    }

    [Fact]
    public void DuplicateUnitIdentifier_InsideCategory_IsRejected()
    {
        Assert.Throws<InvalidOperationException>(() => new UnitCategory(
            "test",
            "test",
            [
                UnitDefinition.Linear("a", "x", "A", 1m),
                UnitDefinition.Linear("b", "x", "B", 2m),
            ]));
    }

    [Fact]
    public void UnknownCategory_ThrowsNotFound() =>
        Assert.Throws<CategoryNotFoundException>(() => new UnitCatalog([]).GetCategory("nope"));
}
